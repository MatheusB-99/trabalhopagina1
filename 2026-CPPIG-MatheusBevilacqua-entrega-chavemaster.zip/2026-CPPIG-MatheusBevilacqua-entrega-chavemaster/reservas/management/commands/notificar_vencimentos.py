from django.core.management.base import BaseCommand
from django.utils import timezone
from django.conf import settings
from django.core.mail import send_mail
from datetime import datetime, timedelta

from reservas.models import Reserva
from emprestimos.models import Emprestimo


def make_aware(dt):
    if timezone.is_naive(dt):
        return timezone.make_aware(dt)
    return dt


class Command(BaseCommand):
    help = 'Envia emails 10 minutos antes do vencimento de reservas e emprestimos'

    def handle(self, *args, **options):
        now = timezone.localtime()
        sent = 0

        # Reservas: usar data_fim + horario_fim
        reservas = Reserva.objects.filter(status='aberta').select_related('usuario')
        for r in reservas:
            if not r.data_fim or not getattr(r, 'horario_fim', None):
                continue
            venc = make_aware(datetime.combine(r.data_fim, r.horario_fim))
            aviso = venc - timedelta(minutes=10)
            if aviso <= now <= venc and not getattr(r, 'notificado_vencimento', False):
                if r.usuario and r.usuario.email:
                    send_mail(
                        'Reserva próxima do vencimento',
                        f'Sua reserva #{r.id} está a 10 minutos de vencer.',
                        settings.DEFAULT_FROM_EMAIL,
                        [r.usuario.email],
                        fail_silently=True,
                    )
                    r.notificado_vencimento = True
                    r.save(update_fields=['notificado_vencimento'])
                    sent += 1

        # Emprestimos: usar data_prevista + horario_prevista
        emprestimos = Emprestimo.objects.filter(status=Emprestimo.StatusEmprestimo.ABERTO).select_related('usuario')
        for e in emprestimos:
            if not e.data_prevista or not getattr(e, 'horario_prevista', None):
                continue
            venc = make_aware(datetime.combine(e.data_prevista, e.horario_prevista))
            aviso = venc - timedelta(minutes=10)
            if aviso <= now <= venc and not getattr(e, 'notificado_vencimento', False):
                if e.usuario and e.usuario.email:
                    send_mail(
                        'Empréstimo próximo do vencimento',
                        f'Seu empréstimo #{e.id} está a 10 minutos de vencer.',
                        settings.DEFAULT_FROM_EMAIL,
                        [e.usuario.email],
                        fail_silently=True,
                    )
                    e.notificado_vencimento = True
                    e.save(update_fields=['notificado_vencimento'])
                    sent += 1

        self.stdout.write(self.style.SUCCESS(f'Notificações enviadas: {sent}'))
