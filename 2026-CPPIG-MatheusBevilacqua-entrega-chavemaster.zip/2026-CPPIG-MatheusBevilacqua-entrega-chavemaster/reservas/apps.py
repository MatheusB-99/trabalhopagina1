from django.apps import AppConfig
import os


class ReservasConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reservas'

    def ready(self):
        # Protege contra o autoreload do runserver que executa o processo duas vezes
        if os.environ.get('RUN_MAIN') != 'true':
            return

        try:
            from .scheduler import start
        except Exception:
            # não falhar a inicialização do app se o scheduler não puder ser importado
            return

        start()
