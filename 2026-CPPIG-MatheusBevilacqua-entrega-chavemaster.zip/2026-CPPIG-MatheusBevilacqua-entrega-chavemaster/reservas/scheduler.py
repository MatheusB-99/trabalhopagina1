from apscheduler.schedulers.background import BackgroundScheduler
from django.core.management import call_command

scheduler = None


def executar_notificacoes():
    # chama o management command que já contém a lógica de notificação
    call_command('notificar_vencimentos')


def start():
    global scheduler
    if scheduler is not None:
        return

    scheduler = BackgroundScheduler()
    scheduler.add_job(
        executar_notificacoes,
        'interval',
        minutes=1,
        id='notificar_vencimentos_job',
        replace_existing=True,
    )
    scheduler.start()
