from django.conf import settings
from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()


class UsuarioPerfil(models.Model):
    """Perfil opcional ligado ao User do Django.

    Substitui o uso direto de um modelo de usuário separado. Mantém
    campos extras como `cpf` e `tipo`.
    """
    TIPO_CHOICES = (
        ('administrador', 'Administrador'),
        ('usuario_normal', 'Usuario normal'),
    )

    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='perfil')
    cpf = models.CharField('CPF', max_length=14, blank=True, null=True)
    tipo = models.CharField('Tipo', max_length=20, choices=TIPO_CHOICES, default='usuario_normal')

    class Meta:
        verbose_name = 'Perfil de Usuario'
        verbose_name_plural = 'Perfis de Usuario'

    def __str__(self):
        return self.user.username
