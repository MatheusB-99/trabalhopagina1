from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.contrib.auth.models import User
from django.db.models import Q
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView

from .forms import UsuarioCreateForm, UsuarioUpdateForm
from .models import UsuarioPerfil


class UsuarioListView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    permission_required = 'auth.view_user'
    model = User
    template_name = 'usuarios.html'
    paginate_by = 8

    def get_queryset(self):
        buscar = self.request.GET.get('buscar')
        qs = super().get_queryset()
        if buscar:
            return qs.filter(
                Q(username__icontains=buscar)
                | Q(email__icontains=buscar)
                | Q(first_name__icontains=buscar)
                | Q(last_name__icontains=buscar)
            )
        return qs


class UsuarioCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    permission_required = 'auth.add_user'
    model = User
    form_class = UsuarioCreateForm
    template_name = 'usuario_form.html'
    success_url = reverse_lazy('usuarios')
    success_message = 'Usuario cadastrado com sucesso!'

    def form_valid(self, form):
        # save user then create profile from POSTed cpf/tipo if present
        response = super().form_valid(form)
        cpf = self.request.POST.get('cpf')
        tipo = self.request.POST.get('tipo')
        UsuarioPerfil.objects.create(user=self.object, cpf=cpf or '', tipo=tipo or 'usuario_normal')
        return response


class UsuarioUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    permission_required = 'auth.change_user'
    model = User
    form_class = UsuarioUpdateForm
    template_name = 'usuario_form.html'
    success_url = reverse_lazy('usuarios')
    success_message = 'Usuario alterado com sucesso!'

    def form_valid(self, form):
        response = super().form_valid(form)
        # update or create profile
        cpf = self.request.POST.get('cpf')
        tipo = self.request.POST.get('tipo')
        perfil, created = UsuarioPerfil.objects.get_or_create(user=self.object)
        perfil.cpf = cpf or perfil.cpf
        perfil.tipo = tipo or perfil.tipo
        perfil.save()
        return response


class UsuarioDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    permission_required = 'auth.delete_user'
    model = User
    template_name = 'usuario_confirm_delete.html'
    success_url = reverse_lazy('usuarios')

    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Usuario apagado com sucesso!')
        return super().delete(request, *args, **kwargs)
