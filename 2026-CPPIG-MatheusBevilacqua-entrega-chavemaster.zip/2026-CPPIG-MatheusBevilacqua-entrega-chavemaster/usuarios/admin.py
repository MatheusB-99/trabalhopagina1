from django.contrib import admin

from .models import Usuario


@admin.register(Usuario)
class UsuarioAdmin(admin.ModelAdmin):
	list_display = ('id', 'nome', 'email', 'tipo', 'cpf')
	list_filter = ('tipo',)
	search_fields = ('nome', 'email', 'cpf')
