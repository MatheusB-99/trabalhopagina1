
from django.contrib import messages
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy
from django.views.generic import CreateView, DeleteView, ListView, UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q

from .forms import EmprestimoForm
from .models import Emprestimo


class EmprestimosView(LoginRequiredMixin, PermissionRequiredMixin, ListView):
    permission_required = 'emprestimos.view_emprestimo'
    model = Emprestimo
    template_name = 'emprestimos.html'
    paginate_by = 8

    def get_queryset(self):
        buscar = self.request.GET.get('buscar')
        qs = super().get_queryset().select_related('usuario', 'copia_chave', 'reserva')
        if buscar:
            return qs.filter(
                Q(usuario__username__icontains=buscar)
                | Q(usuario__email__icontains=buscar)
                | Q(usuario__first_name__icontains=buscar)
                | Q(usuario__last_name__icontains=buscar)
            )
        return qs


class EmprestimoCreateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, CreateView):
    permission_required = 'emprestimos.add_emprestimo'
    model = Emprestimo
    form_class = EmprestimoForm
    template_name = 'emprestimo_form.html'
    success_url = reverse_lazy('emprestimos')
    success_message = 'Emprestimo cadastrado com sucesso!'


class EmprestimoUpdateView(LoginRequiredMixin, PermissionRequiredMixin, SuccessMessageMixin, UpdateView):
    permission_required = 'emprestimos.change_emprestimo'
    model = Emprestimo
    form_class = EmprestimoForm
    template_name = 'emprestimo_form.html'
    success_url = reverse_lazy('emprestimos')
    success_message = 'Emprestimo alterado com sucesso!'


class EmprestimoDeleteView(LoginRequiredMixin, PermissionRequiredMixin, DeleteView):
    permission_required = 'emprestimos.delete_emprestimo'
    model = Emprestimo
    template_name = 'emprestimo_confirm_delete.html'
    success_url = reverse_lazy('emprestimos')

    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Emprestimo apagado com sucesso!')
        return super().delete(request, *args, **kwargs)
