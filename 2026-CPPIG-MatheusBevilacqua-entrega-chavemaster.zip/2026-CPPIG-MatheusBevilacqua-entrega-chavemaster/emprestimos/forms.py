﻿from django import forms

from copias.models import CopiaChave
from .models import Emprestimo


class EmprestimoForm(forms.ModelForm):
    data_inicio = forms.DateField(
        label='Data de início',
        required=True,
        widget=forms.DateInput(attrs={'type': 'date'}),
        help_text='Data de início do empréstimo',
    )
    horario_inicio = forms.TimeField(
        label='Horário de início',
        required=True,
        widget=forms.TimeInput(attrs={'type': 'time'}),
        help_text='Horário de início do empréstimo',
    )
    data_fim = forms.DateField(
        label='Data de término',
        required=True,
        widget=forms.DateInput(attrs={'type': 'date'}),
        help_text='Data de término previsto do empréstimo',
    )
    horario_fim = forms.TimeField(
        label='Horário de término',
        required=True,
        widget=forms.TimeInput(attrs={'type': 'time'}),
        help_text='Horário de término previsto do empréstimo',
    )

    class Meta:
        model = Emprestimo
        fields = [
            'usuario',
            'copia_chave',
            'reserva',
            'data_inicio',
            'horario_inicio',
            'data_fim',
            'horario_fim',
            'data_devolucao',
            'horario_devolucao',
            'status',
        ]
        error_messages = {
            'usuario': {'required': 'O usuario do emprestimo e um campo obrigatorio'},
            'copia_chave': {'required': 'A copia da chave e um campo obrigatorio'},
            'reserva': {'required': 'A reserva do emprestimo e um campo obrigatorio'},
            'data_devolucao': {'required': 'A data de devolucao e um campo obrigatorio'},
            'status': {'required': 'O status do emprestimo e um campo obrigatorio'},
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['copia_chave'].queryset = CopiaChave.objects.filter(chave__tipo='sala')

        if self.instance and self.instance.pk:
            self.fields['data_inicio'].initial = self.instance.data_retirada
            self.fields['horario_inicio'].initial = self.instance.horario_retirada
            self.fields['data_fim'].initial = self.instance.data_prevista
            self.fields['horario_fim'].initial = self.instance.horario_prevista

    def clean(self):
        cleaned_data = super().clean()
        data_inicio = cleaned_data.get('data_inicio')
        horario_inicio = cleaned_data.get('horario_inicio')
        data_fim = cleaned_data.get('data_fim')
        horario_fim = cleaned_data.get('horario_fim')

        if not data_inicio or not horario_inicio or not data_fim or not horario_fim:
            raise forms.ValidationError('Os campos de início e término do empréstimo são obrigatórios.')

        if data_inicio > data_fim or (data_inicio == data_fim and horario_inicio >= horario_fim):
            raise forms.ValidationError('A data e horário de término devem ser posteriores ao início.')

        return cleaned_data

    def save(self, commit=True):
        emprestimo = super().save(commit=False)
        emprestimo.data_retirada = self.cleaned_data.get('data_inicio')
        emprestimo.horario_retirada = self.cleaned_data.get('horario_inicio')
        emprestimo.data_prevista = self.cleaned_data.get('data_fim')
        emprestimo.horario_prevista = self.cleaned_data.get('horario_fim')

        if commit:
            emprestimo.save()
            self.save_m2m()

        return emprestimo

    def clean_copia_chave(self):
        copia_chave = self.cleaned_data.get('copia_chave')
        if copia_chave and copia_chave.chave.tipo == 'predio':
            raise forms.ValidationError('Chave de predio nao pode ser emprestada.')
        return copia_chave
